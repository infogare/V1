Lire en [[Français]](https://github.com/Absolument-Oui/InfoGares/blob/main/README.md)

# InfoGare

Infogare, create infogares become easy!

## Join the beta

You can submit your application to join the beta version of Infogare on our Discord server.

The number of places is limited !
 
## For Volunteers

Do not hesitate to join us on our Discord in order to make feedback and suggestions.

## Contact

E-mail: [contact@infogare.fr](mailto:contact@infogare.fr)

Discord: [discord.com/invite/jvsfzxkcdz](discord.com/invite/jvsfzxkcdz)
