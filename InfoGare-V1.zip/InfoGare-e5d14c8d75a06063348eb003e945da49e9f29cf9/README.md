Read in [[English]](https://github.com/Absolument-Oui/InfoGares/blob/main/README_en.md)

# InfoGare

InfoGare, créer des infogares deviens facile !

## Rejoindre la bêta

Vous pouvez remplir notre formulaire pour rejoindre la version bêta de InfoGare ici : https://link.infogare.fr/JoinBeta

Le nombre de places est limité !
 
## Pour les volontaires

N'hésitez pas à nous rejoindre sur notre Discord afin de nous faire des retours et des suggestions.

## Contact

E-mail : [contact@infogare.fr](mailto:contact@infogare.fr)

Discord : https://link.infogare.fr/Discord
